<?php
// Database
$servername = "localhost";
$username = "dbuser";
$password = "123";
$dbname = "ahab_db";


// $servername = "ahab-113437.mysql.binero.se";
// $username = "113437_hu85225";
// $password = "hydrography";
// $dbname = "113437-ahab";

$configuration_values = array("Chiroptera", "DualDragon", "HawkEyeIII", "Chiroptera (HEIII)");
$sensor_status_values = array("New", "Done", "Broken", "Service", "PIA");
$scu_status_values = array("New", "Done", "Fixed", "Service", "PIA");
$system_status_values = array("New", "Done", "Fixed", "Service", "PIA");
?>